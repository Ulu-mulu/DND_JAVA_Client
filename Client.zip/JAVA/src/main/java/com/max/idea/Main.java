package com.max.idea;

public class Main {
    public static void main(String[] args) {
        ClientUI clientUI = new ClientUI();
        clientUI.setVisible(true);
    }
}
